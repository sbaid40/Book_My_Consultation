package com.upgrad.ratingservice.exception;

public class RatingValueInvalidException extends RuntimeException{
}
