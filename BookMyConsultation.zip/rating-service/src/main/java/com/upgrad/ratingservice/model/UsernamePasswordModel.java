package com.upgrad.ratingservice.model;

import lombok.Data;

@Data
public class UsernamePasswordModel {
    private String username;
    private String password;
}
