package com.upgrad.ratingservice.model;

public enum ApplicationPermission {
    READ,WRITE
}
