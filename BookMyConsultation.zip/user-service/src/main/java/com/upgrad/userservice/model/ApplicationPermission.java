package com.upgrad.userservice.model;

public enum ApplicationPermission {
    READ,WRITE
}
