package com.upgrad.userservice.exception;

public class RequestedResourceNotFoundException extends RuntimeException{
}