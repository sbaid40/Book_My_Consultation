package com.upgrad.userservice.model;

import lombok.Data;

@Data
public class UsernamePasswordModel {
    private String username;
    private String password;
}
