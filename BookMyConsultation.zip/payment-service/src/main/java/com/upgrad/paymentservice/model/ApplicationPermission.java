package com.upgrad.paymentservice.model;

public enum ApplicationPermission {
    READ,WRITE
}
