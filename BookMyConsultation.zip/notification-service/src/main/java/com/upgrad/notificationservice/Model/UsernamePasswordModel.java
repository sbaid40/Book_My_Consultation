package com.upgrad.notificationservice.Model;

import lombok.Data;

@Data
public class UsernamePasswordModel {
    private String username;
    private String password;
}
