package com.upgrad.notificationservice.Model;

public enum Status {
    PENDING,ACTIVE,REJECTED;
}
