package com.upgrad.doctorservice.model;

public enum Status {
    PENDING,ACTIVE,REJECTED;
}
