package com.upgrad.doctorservice.model;

public enum ApplicationPermission {
    READ,WRITE
}
