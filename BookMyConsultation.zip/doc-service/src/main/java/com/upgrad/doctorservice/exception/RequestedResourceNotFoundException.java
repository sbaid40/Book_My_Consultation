package com.upgrad.doctorservice.exception;

public class RequestedResourceNotFoundException extends RuntimeException{
}