package com.upgrad.auth.model;

public enum ApplicationPermission {
    READ,WRITE
}
