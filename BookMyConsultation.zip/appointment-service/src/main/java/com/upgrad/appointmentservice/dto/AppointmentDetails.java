package com.upgrad.appointmentservice.dto;

public class AppointmentDetails {
    private String appointmentId;
    private String doctorId;
    private String userId;
    private String appointmentDate;
    private String timeSlot;
    private String status;
}
