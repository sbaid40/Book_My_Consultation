package com.upgrad.appointmentservice.exception;

public class RequestedResourceNotFoundException extends RuntimeException{
}