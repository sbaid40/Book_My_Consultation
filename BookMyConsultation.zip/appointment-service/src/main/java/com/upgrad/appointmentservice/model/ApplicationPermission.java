package com.upgrad.appointmentservice.model;

public enum ApplicationPermission {
    READ,WRITE
}
