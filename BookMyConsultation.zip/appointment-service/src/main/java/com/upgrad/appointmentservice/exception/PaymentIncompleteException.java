package com.upgrad.appointmentservice.exception;

public class PaymentIncompleteException extends RuntimeException{
}
